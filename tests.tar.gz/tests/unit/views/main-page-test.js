// import { moduleFor, test } from 'ember-qunit';
//
// moduleFor('view:main-page', 'Unit | View | main page');
//
// // Replace this with your real tests.
// test('it exists', function(assert) {
//   var view = this.subject();
//   assert.ok(view);
// });
