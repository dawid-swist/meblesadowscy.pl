import { moduleForModel, test } from 'ember-qunit';
import Ember from 'ember';
//
// moduleForModel('player', 'Unit | Model | player', {
//   // Specify the other units that are required for this test.
//   needs: []
// });
//


moduleForModel('player');

test('it exists', function(assert) {
  let model = this.subject();
  // let store = this.store();
  assert.ok(!!model);
});

test('levelUp', function(assert) {
  // this.subject aliases the createRecord method on the model
  var player = this.subject({ level: 4 });

  // wrap asynchronous call in run loop
  Ember.run(function() {
    player.levelUp();
  });

  assert.equal(player.get('level'), 5);
  assert.equal(player.get('levelName'), 'Professional');
});
