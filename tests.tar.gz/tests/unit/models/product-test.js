// import { moduleForModel, test } from 'ember-qunit';
// // import Ember from 'ember';
//
//
// moduleForModel('product ', 'Unit | Model | product', {
//   // Specify the other units that are required for this test.
//   needs: []
// });
//
// test('it exists', function(assert) {
//   var model = this.subject();
//
//   var product = model.create({});
//
//
//
//   // var store = this.store();
//   assert.ok(!!product);
// });
